# ML hw10
r13922193 渠景量

 ## 環境
 我是用kaggle跑的 GPU為T4 x2

## object 1 ~ 4
 ```
r13922193_hw10_1.ipynb
 ```
## object 5
 ```
r13922193_hw10_2.ipynb
 ```
## object 6
```
r13922193_hw10_3.ipynb
```

## How to run
將 r13922193_hw10_1.ipynb、r13922193_hw10_2.ipynb、r13922193_hw10_3.ipynb 分別上傳至kaggle，然後run all，再將他們的results下載下來，然後把r13922193_hw10_1.ipynb的results中的object 5用r13922193_hw10_2.ipynb的results替代，把r13922193_hw10_1.ipynb的results中的object 6用r13922193_hw10_3.ipynb的results替代，再重新壓回results.zip