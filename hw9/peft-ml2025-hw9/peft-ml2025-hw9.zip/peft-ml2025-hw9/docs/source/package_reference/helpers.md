<!--⚠️ Note that this file is in Markdown but contain specific syntax for our doc-builder (similar to MDX) that may not be
rendered properly in your Markdown viewer.
-->

# Document Title

A collection of helper functions for PEFT.

## Checking if a model is a PEFT model

[[autodoc]] helpers.check_if_peft_model
    - all
